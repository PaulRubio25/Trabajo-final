from fastapi import APIRouter, Request, HTTPException
from modulos.tareas.acceso_datos.get_factory import obtener_fabrica
from modulos.tareas.acceso_datos.tarea_dto import TareaDTO
from modulos.tareas.notificaciones.sujeto import TareaSubject
from modulos.tareas.notificaciones.observador import RecordatorioNotificador, TareaUrgenteNotificador



dao = obtener_fabrica().crear_dao()
router = APIRouter()

sujeto_tarea = TareaSubject()
sujeto_tarea.agregar_observador(RecordatorioNotificador())
sujeto_tarea.agregar_observador(TareaUrgenteNotificador())

@router.post("/")
async def crear_tarea(req: Request):
    data = await req.json()
  
    tarea = TareaDTO(
        dia=data["dia"],
        hora=data["hora"],
        descripcion=data["descripcion"]
    )
    dao.guardar(tarea)
    
    sujeto_tarea.notificar(tarea) 
    
    return {"mensaje": "Tarea almacenada correctamente."}

@router.get("/")
def obtener_tareas():
    tareas = dao.obtener_todos()
    # Modificar para formatear la hora antes de devolver
    return [
        {
            "id_tarea": t.id_tarea,
            "dia": t.dia,
            "hora": str(t.hora),  # Convertir el objeto datetime.time a string
            "descripcion": t.descripcion
        }
        for t in tareas
    ]

@router.get("/{id_tarea}")
def obtener_tarea(id_tarea: int):
    tarea = dao.obtener_por_id(id_tarea)
    if not tarea:
        raise HTTPException(status_code=404, detail="Tarea no encontrada")
    # Modificar para formatear la hora antes de devolver
    return {
        "id_tarea": tarea.id_tarea,
        "dia": tarea.dia,
        "hora": str(tarea.hora), # Convertir el objeto datetime.time a string
        "descripcion": tarea.descripcion
    }

@router.put("/{id_tarea}")
async def actualizar_tarea(id_tarea: int, req: Request):
    data = await req.json()

    tarea_actualizada = TareaDTO(
        id_tarea=id_tarea,
        dia=data["dia"],
        hora=data["hora"],
        descripcion=data["descripcion"]
    )
    dao.actualizar(tarea_actualizada)
    return {"mensaje": "Tarea actualizada correctamente."}

@router.delete("/{id_tarea}")
def eliminar_tarea(id_tarea: int):
    dao.eliminar(id_tarea)
    return {"mensaje": "Tarea eliminada correctamente."}