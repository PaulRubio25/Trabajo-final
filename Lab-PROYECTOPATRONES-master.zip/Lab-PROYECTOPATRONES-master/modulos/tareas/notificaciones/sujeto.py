class TareaSubject:
    def __init__(self):
        self.observadores = []

    def agregar_observador(self, observador):
        self.observadores.append(observador)

    def notificar(self, tarea):
        for observador in self.observadores:
            observador.actualizar(tarea)
