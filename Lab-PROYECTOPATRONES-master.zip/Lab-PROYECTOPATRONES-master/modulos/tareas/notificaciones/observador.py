import logging
from abc import ABC, abstractmethod

# Configurar logging para guardar notificaciones en archivo
logging.basicConfig(
    filename="modulos/tareas/logs/notificaciones.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

# Interfaz abstracta para los observadores
class ObservadorTarea(ABC):
    @abstractmethod
    def actualizar(self, tarea):
        pass

class RecordatorioNotificador(ObservadorTarea):
    def actualizar(self, tarea):
        """Notifica sobre una nueva tarea creada, actuando como un recordatorio."""
        mensaje = f"[Recordatorio] Tarea para el día {tarea.dia} a las {tarea.hora}. Descripción: '{tarea.descripcion}'"
        print(mensaje)
        logging.info(mensaje)

class TareaUrgenteNotificador(ObservadorTarea):
    def actualizar(self, tarea):
        """Revisa la descripción de la tarea en busca de la palabra 'urgente' para emitir una alerta."""
        if "urgente" in tarea.descripcion.lower():
            mensaje = f"[ALERTA URGENTE] Se ha registrado una tarea urgente: {tarea.descripcion}"
            print(mensaje)
            logging.warning(mensaje)