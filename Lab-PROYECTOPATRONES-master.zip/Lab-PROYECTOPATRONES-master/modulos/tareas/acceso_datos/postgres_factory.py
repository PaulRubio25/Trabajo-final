from modulos.tareas.acceso_datos.tarea_dao import TareaDAOPostgres
from modulos.tareas.acceso_datos.dao_factory import TareaDAOFactory

class PostgresTareaDAOFactory(TareaDAOFactory):
    def crear_dao(self):
        return TareaDAOPostgres()