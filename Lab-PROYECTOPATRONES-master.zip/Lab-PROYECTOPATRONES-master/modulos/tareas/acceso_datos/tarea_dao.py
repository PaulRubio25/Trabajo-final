from modulos.tareas.acceso_datos.tarea_dto import TareaDTO
from modulos.tareas.acceso_datos.conexion import ConexionDB

conn = ConexionDB().obtener_conexion()

class TareaDAOMySQL:
    def guardar(self, tarea_dto):
        with conn.cursor() as cursor:
            sql = "INSERT INTO Tareas (dia, hora, descripcion) VALUES (%s, %s, %s)"
            cursor.execute(sql, (tarea_dto.dia, tarea_dto.hora, tarea_dto.descripcion))
        conn.commit()

    def obtener_todos(self):
        with conn.cursor() as cursor:
            cursor.execute("SELECT id_tarea, dia, hora, descripcion FROM Tareas")
            rows = cursor.fetchall()
        return [TareaDTO(id_tarea=row[0], dia=row[1], hora=row[2], descripcion=row[3]) for row in rows]

    def obtener_por_id(self, id_tarea):
        with conn.cursor() as cursor:
            cursor.execute("SELECT id_tarea, dia, hora, descripcion FROM Tareas WHERE id_tarea = %s", (id_tarea,))
            row = cursor.fetchone()
        if row:
            return TareaDTO(id_tarea=row[0], dia=row[1], hora=row[2], descripcion=row[3])
        return None

    def actualizar(self, tarea_dto):
        with conn.cursor() as cursor:
            sql = "UPDATE Tareas SET dia = %s, hora = %s, descripcion = %s WHERE id_tarea = %s"
            cursor.execute(sql, (tarea_dto.dia, tarea_dto.hora, tarea_dto.descripcion, tarea_dto.id_tarea))
        conn.commit()

    def eliminar(self, id_tarea):
        with conn.cursor() as cursor:
            cursor.execute("DELETE FROM Tareas WHERE id_tarea = %s", (id_tarea,))
        conn.commit()


class TareaDAOPostgres:
    def guardar(self, tarea_dto):
        with conn.cursor() as cursor:
            sql = "INSERT INTO Tareas (dia, hora, descripcion) VALUES (%s, %s, %s)"
            cursor.execute(sql, (tarea_dto.dia, tarea_dto.hora, tarea_dto.descripcion))
        conn.commit()

    def obtener_todos(self):
        with conn.cursor() as cursor:
            cursor.execute("SELECT id_tarea, dia, hora, descripcion FROM Tareas")
            rows = cursor.fetchall()
        return [TareaDTO(id_tarea=row[0], dia=row[1], hora=row[2], descripcion=row[3]) for row in rows]

    def obtener_por_id(self, id_tarea):
        with conn.cursor() as cursor:
            cursor.execute("SELECT id_tarea, dia, hora, descripcion FROM Tareas WHERE id_tarea = %s", (id_tarea,))
            row = cursor.fetchone()
        if row:
            return TareaDTO(id_tarea=row[0], dia=row[1], hora=row[2], descripcion=row[3])
        return None

    def actualizar(self, tarea_dto):
        with conn.cursor() as cursor:
            sql = "UPDATE Tareas SET dia = %s, hora = %s, descripcion = %s WHERE id_tarea = %s"
            cursor.execute(sql, (tarea_dto.dia, tarea_dto.hora, tarea_dto.descripcion, tarea_dto.id_tarea))
        conn.commit()

    def eliminar(self, id_tarea):
        with conn.cursor() as cursor:
            cursor.execute("DELETE FROM Tareas WHERE id_tarea = %s", (id_tarea,))
        conn.commit()

