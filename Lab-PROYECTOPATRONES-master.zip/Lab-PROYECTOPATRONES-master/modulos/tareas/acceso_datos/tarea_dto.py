class TareaDTO:
    def __init__(self, id_tarea=None, dia=None, hora=None, descripcion=""):
        self.id_tarea = id_tarea
        self.dia = dia
        self.hora = hora
        self.descripcion = descripcion

    def __str__(self):
        return f"TareaDTO(id_tarea={self.id_tarea}, dia='{self.dia}', hora='{self.hora}', descripcion='{self.descripcion}')"