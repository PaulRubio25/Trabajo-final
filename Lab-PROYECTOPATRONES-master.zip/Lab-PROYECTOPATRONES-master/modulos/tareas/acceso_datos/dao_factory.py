class TareaDAOFactory:
    def crear_dao(self):
        raise NotImplementedError