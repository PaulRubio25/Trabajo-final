from modulos.tareas.acceso_datos.tarea_dao import TareaDAOMySQL
from modulos.tareas.acceso_datos.dao_factory import TareaDAOFactory

class MySQLTareaDAOFactory(TareaDAOFactory):
    def crear_dao(self):
        return TareaDAOMySQL()