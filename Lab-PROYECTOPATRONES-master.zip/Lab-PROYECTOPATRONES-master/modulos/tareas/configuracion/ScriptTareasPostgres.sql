REATE TABLE Tareas (
    id_tarea SERIAL PRIMARY KEY,
    dia DATE,
    hora TIME,
    descripcion TEXT
);
