CREATE TABLE Tareas (
    id_tarea INT AUTO_INCREMENT PRIMARY KEY,
    dia DATE,
    hora TIME,
    descripcion TEXT
);
