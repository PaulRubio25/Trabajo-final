import tkinter as tk
from tkinter import ttk, messagebox
import requests
import json

# Cargar configuración desde config.json
with open("../../modulos/tareas/configuracion/config.json") as f:
    config = json.load(f)

API = config["api_base"]
ENDPOINTS = config["endpoints"]

def recargar_datos():
    for item in tree.get_children():
        tree.delete(item)
    try:
        r = requests.get(API + ENDPOINTS["read_all"])
        if r.status_code == 200:
            for t in r.json():
                tree.insert("", "end", values=(
                    t["id_tarea"], t["dia"], t["hora"], t["descripcion"]
                ))
    except Exception as e:
        messagebox.showerror("Error", str(e))

def crear_tarea():
    dialogo_tarea("Crear nueva tarea")

def editar_tarea():
    seleccionado = tree.focus()
    if not seleccionado:
        messagebox.showwarning("Seleccionar", "Seleccione una tarea.")
        return
    valores = tree.item(seleccionado, "values")
    dialogo_tarea("Editar tarea", valores)

def eliminar_tarea():
    seleccionado = tree.focus()
    if not seleccionado:
        messagebox.showwarning("Seleccionar", "Seleccione una tarea.")
        return
    id_tarea = tree.item(seleccionado, "values")[0]
    if messagebox.askyesno("Eliminar", "¿Seguro que desea eliminar esta tarea?"):
        try:
            url_delete = ENDPOINTS["delete"].replace("{id}", str(id_tarea))
            r = requests.delete(API + url_delete)
            if r.status_code == 200:
                recargar_datos()
                messagebox.showinfo("Éxito", "Tarea eliminada.")
            else:
                messagebox.showerror("Error", r.text)
        except Exception as e:
            messagebox.showerror("Error", str(e))

def dialogo_tarea(titulo, datos=None):
    ventana = tk.Toplevel(root)
    ventana.title(titulo)

    tk.Label(ventana, text="Día (YYYY-MM-DD):").grid(row=0, column=0, padx=5, pady=5)
    dia = tk.Entry(ventana)
    dia.grid(row=0, column=1, padx=5, pady=5)

    tk.Label(ventana, text="Hora (HH:MM:SS):").grid(row=1, column=0, padx=5, pady=5)
    hora = tk.Entry(ventana)
    hora.grid(row=1, column=1, padx=5, pady=5)

    tk.Label(ventana, text="Descripción:").grid(row=2, column=0, padx=5, pady=5)
    descripcion = tk.Entry(ventana)
    descripcion.grid(row=2, column=1, padx=5, pady=5)

    if datos:
        id_tarea, dia_val, hora_val, descripcion_val = datos
        dia.insert(0, dia_val)
        hora.insert(0, hora_val)
        descripcion.insert(0, descripcion_val)

    def guardar():
        payload = {
            "dia": dia.get(),
            "hora": hora.get(),
            "descripcion": descripcion.get()
        }
        try:
            if datos:
                url_update = ENDPOINTS["update"].replace("{id}", str(id_tarea))
                r = requests.put(API + url_update, json=payload)
            else:
                r = requests.post(API + ENDPOINTS["create"], json=payload)
            if r.status_code in [200, 201]:
                recargar_datos()
                ventana.destroy()
                messagebox.showinfo("Éxito", "Operación exitosa.")
            else:
                messagebox.showerror("Error", r.text)
        except Exception as e:
            messagebox.showerror("Error", str(e))

    tk.Button(ventana, text="Guardar", command=guardar).grid(row=3, columnspan=2, pady=10)

# Ventana principal
root = tk.Tk()
root.title("Gestión de Tareas")

# Tabla
cols = ("ID", "Día", "Hora", "Descripción")
tree = ttk.Treeview(root, columns=cols, show="headings")
for col in cols:
    tree.heading(col, text=col)
    tree.column(col, anchor="center", width=150)
tree.pack(fill="both", expand=True, padx=10, pady=10)

# Botones CRUD
botonera = tk.Frame(root)
botonera.pack(pady=10)

tk.Button(botonera, text="Nuevo", command=crear_tarea).pack(side="left", padx=5)
tk.Button(botonera, text="Editar", command=editar_tarea).pack(side="left", padx=5)
tk.Button(botonera, text="Eliminar", command=eliminar_tarea).pack(side="left", padx=5)
tk.Button(botonera, text="Recargar", command=recargar_datos).pack(side="left", padx=5)

recargar_datos()
root.mainloop()
