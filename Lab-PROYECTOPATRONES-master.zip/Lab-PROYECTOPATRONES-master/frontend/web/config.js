const API_BASE = "http://localhost:8000";
const ENDPOINTS = {
    create: "/tareas",
    read_all: "/tareas",
    read_one: "/tareas/{id}",
    update: "/tareas/{id}",
    delete: "/tareas/{id}"
};
