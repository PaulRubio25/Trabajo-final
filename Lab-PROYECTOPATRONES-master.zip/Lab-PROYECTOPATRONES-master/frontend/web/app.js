const API_PRODUCTOS = "http://localhost:8000/productos/";

// Función para listar todas las tareas
async function listarTareas() {
    const res = await fetch(API_BASE + ENDPOINTS.read_all);
    const data = await res.json();
    const lista = document.getElementById("listaTareas");
    lista.innerHTML = "";
    data.forEach(t => {
        const item = document.createElement("li");
        item.textContent = `ID: ${t.id_tarea} - Día: ${t.dia} - Hora: ${t.hora} - Descripción: ${t.descripcion}`;
        lista.appendChild(item);
    });
}

// Evento para el formulario de crear tarea
document.getElementById("formTarea").addEventListener("submit", async function(e) {
    e.preventDefault();
    const dia = document.getElementById("dia").value;
    const hora = document.getElementById("hora").value;
    const descripcion = document.getElementById("descripcion").value;
  
    
    const body = { dia, hora, descripcion };
    
    const res = await fetch(API_BASE + ENDPOINTS.create, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(body)
    });
    
    const result = await res.json();
    if (res.ok) {
        alert("Tarea creada.");
        listarTareas();
        mostrarSeccion('lista');
    } else {
        alert(`Error al crear la tarea: ${result.detail}`);
    }
});

// Función para buscar una tarea por ID
async function buscarTarea() {
    const id = document.getElementById("idBuscar").value;
    const res = await fetch(API_BASE + ENDPOINTS.read_one.replace("{id}", id));
    if (res.ok) {
        const data = await res.json();
        document.getElementById("diaAccion").value = data.dia;
        document.getElementById("horaAccion").value = data.hora;
        document.getElementById("descripcionAccion").value = data.descripcion;
        mostrarSeccion('acciones');
        alert("Tarea cargada para edición.");
    } else {
        alert("Tarea no encontrada.");
    }
}

// Función para actualizar una tarea
async function actualizarTarea() {
    const id = document.getElementById("idBuscar").value;
    const body = {
        dia: document.getElementById("diaAccion").value,
        hora: document.getElementById("horaAccion").value,
        descripcion: document.getElementById("descripcionAccion").value
    };
    const res = await fetch(API_BASE + ENDPOINTS.update.replace("{id}", id), {
        method: "PUT",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(body)
    });
    const result = await res.json();
    alert(result.mensaje || "Actualizado");
    listarTareas();
    mostrarSeccion('lista');
}

// Función para eliminar una tarea
async function eliminarTarea() {
    const id = document.getElementById("idBuscar").value;
    const res = await fetch(API_BASE + ENDPOINTS.delete.replace("{id}", id), { method: "DELETE" });
    const result = await res.json();
    alert(result.mensaje || "Eliminado");
    listarTareas();
    mostrarSeccion('lista');
}

// Función para mostrar las diferentes secciones de la interfaz
function mostrarSeccion(id) {
    document.querySelectorAll(".seccion").forEach(s => s.style.display = "none");
    document.getElementById(id).style.display = "block";
}

// Inicializar la aplicación al cargar la página
listarTareas();
mostrarSeccion('crear');