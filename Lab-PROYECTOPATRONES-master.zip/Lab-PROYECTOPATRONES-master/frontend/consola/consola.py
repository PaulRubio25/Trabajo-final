import requests
import json
import datetime as dt


# === Configuración comentarios ===
with open("../../modulos/tareas/configuracion/config.json") as f:
    config = json.load(f)

API_TAREAS = config["api_base"]
ENDPOINTS = config["endpoints"]


# === Tareas ===
def menu_tareas():
    print("\n===== Menú Tareas =====")
    print("1. Ingresar nueva tarea")
    print("2. Listar todas las tareas")
    print("3. Obtener tarea por ID")
    print("4. Actualizar tarea")
    print("5. Eliminar tarea")
    print("6. Volver")

def ingresar_tarea():
    dia = input("Día (YYYY-MM-DD): ") 

    try:
        dia_ingresado = dt.datetime.strptime(dia,"%Y-%m-%d").date()

        if dia_ingresado < dt.date.today():
            print("Error: La fecha no es actual")
            return
    except ValueError:
        print("Error: Formato de fecha no válido.")
        return


    hora = input("Hora (HH:MM:SS): ")
    descripcion = input("Descripción: ")
    r = requests.post(f"{API_TAREAS}{ENDPOINTS['create']}", json={
        "dia": dia,
        "hora": hora,
        "descripcion": descripcion
    })
    print(r.json())

def listar_tareas():
    r = requests.get(f"{API_TAREAS}{ENDPOINTS['read_all']}")
    for t in r.json():
        print(t)

def obtener_tarea():
    id_tarea = input("ID de la tarea: ")
    url = ENDPOINTS["read_one"].replace("{id}", id_tarea)
    r = requests.get(f"{API_TAREAS}{url}")
    print(r.json() if r.status_code == 200 else "Tarea no encontrada.")

def actualizar_tarea():
    id_tarea = input("ID a actualizar: ")
    dia = input("Nuevo día (YYYY-MM-DD): ")
    hora = input("Nueva hora (HH:MM:SS): ")
    descripcion = input("Nueva descripción: ")
    url = ENDPOINTS["update"].replace("{id}", id_tarea)
    r = requests.put(f"{API_TAREAS}{url}", json={
        "dia": dia,
        "hora": hora,
        "descripcion": descripcion
    })
    print(r.json())

def eliminar_tarea():
    id_tarea = input("ID a eliminar: ")
    url = ENDPOINTS["delete"].replace("{id}", id_tarea)
    r = requests.delete(f"{API_TAREAS}{url}")
    print(r.json())


# === Menú principal ===
while True:
    menu_tareas()
    opcion = input("Seleccione una opción: ")

    if opcion == "1":
        ingresar_tarea()
    elif opcion == "2":
        listar_tareas()
    elif opcion == "3":
        obtener_tarea()
    elif opcion == "4":
        actualizar_tarea()
    elif opcion == "5":
        eliminar_tarea()
    elif opcion == "6":
        break
    else:
        print("Opción no válida. Intente de nuevo.")

print("Saliendo del programa.")